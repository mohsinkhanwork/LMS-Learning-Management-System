<?php

return [
    'reads_left_to_right' => true,
    'min' => 'мин',
    'minute' => 'минута',
    'sec' => 'сек',
    'second' => 'секунда',
    'read' => 'четене'
];
