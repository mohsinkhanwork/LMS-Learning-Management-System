<?php

return [
    'reads_left_to_right' => true,
    'min' => 'min',
    'minute' => 'minuut',
    'sec' => 'sec',
    'second' => 'seconde',
    'read' => 'leestijd'
];
