<?php

return [
    'reads_left_to_right' => true,
    'min' => 'min',
    'minute' => 'minut',
    'sec' => 'seg',
    'second' => 'segon',
    'read' => 'llegir'
];
