<?php

return [
    'reads_left_to_right' => true,
    'min' => 'min',
    'minute' => 'minute',
    'sec' => 'sec',
    'second' => 'second',
    'read' => 'read'
];
