<?php

return [
    'reads_left_to_right' => true,
    'min' => 'min',
    'minute' => 'minuto',
    'sec' => 'seg',
    'second' => 'segundo',
    'read' => 'leer'
];
