<?php

return [
    'reads_left_to_right' => true,
    'min' => 'мин.',
    'minute' => 'минут',
    'sec' => 'сек.',
    'second' => 'секунд',
    'read' => 'чтения'
];
