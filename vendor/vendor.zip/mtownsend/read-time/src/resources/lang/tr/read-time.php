<?php

return [
    'reads_left_to_right' => true,
    'min' => 'dk',
    'minute' => 'dakika',
    'sec' => 'sn',
    'second' => 'saniye',
    'read' => 'okuma süresi'
];
