<?php

return [
    'reads_left_to_right' => true,
    'min' => 'хв.',
    'minute' => 'хвилин',
    'sec' => 'сек.',
    'second' => 'секунд',
    'read' => 'читання'
];
